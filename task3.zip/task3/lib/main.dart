import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_localizations.dart';


class SettingsScreen extends StatelessWidget {
  final Function(String) changeLanguage;
  SettingsScreen({required this.changeLanguage});
void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale _locale = Locale('en');

  @override
  void initState() {
    super.initState();
    _loadLocale();
  }

  Future<void> _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final languageCode = prefs.getString('languageCode') ?? 'en';
    setState(() {
      _locale = Locale(languageCode);
    });
  }

  void _changeLanguage(String languageCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('languageCode', languageCode);
    setState(() {
      _locale = Locale(languageCode);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      locale: _locale,
      supportedLocales: [Locale('en'), Locale('es')],
      localizationsDelegates: [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      home: SettingsScreen(changeLanguage: _changeLanguage),
    );
  }
}
  @override
  Widget build(BuildContext context) {
  return Scaffold(
  appBar: AppBar(
  title: Text(AppLocalizations.of(context).translate('settings')),
  ),
  body: Center(
  child: Column(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [
  Text(AppLocalizations.of(context).translate('select_language')),
  DropdownButton<String>(
  value: Localizations.localeOf(context).languageCode,
  items: [
  DropdownMenuItem(value: 'en', child: Text('English')),
  DropdownMenuItem(value: 'es', child: Text('Español')),
  ],
  onChanged: (String? languageCode) {
  if (languageCode != null) {
  changeLanguage(languageCode);
  }
  },
  ),
  ],
  ),
  ),
  );
  }
}